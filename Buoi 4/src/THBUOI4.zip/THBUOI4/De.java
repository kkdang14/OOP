package THBUOI4;

public class De extends ConVat{
	//@Override
	public void Keu() {
		System.out.println("+ Con dê kêu: Be..he..he!");
	}
	
	public void nhapThongTin() {
		System.out.println("Nhập thông tin dê: ");
		super.nhapThongTin();
	}
	
	public void hienThi() {
		System.out.println("Thông tin dê: ");
		super.hienThi();
	}
}

