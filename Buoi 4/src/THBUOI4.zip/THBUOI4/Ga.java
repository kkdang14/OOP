package THBUOI4;

public class Ga extends ConVat {
	public void Keu() {
		System.out.println("+ Con gà kêu: Ò.. ó.. o");
	}
	
	public void nhapThongTin() {
		System.out.println("Nhập thông tin gà: ");
		super.nhapThongTin();
	}
	
	public void hienThi() {
		System.out.println("Thông tin gà: ");
		super.hienThi();
	}

}
